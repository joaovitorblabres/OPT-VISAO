# Rodar:
python main.py

# Deixar o video com nome "SilhouetteJogger.mp4" no mesmo diretório do arquivo Python, ele mostrará a saída do vídeo na tela e salvará frame a frame em uma pasta "imgs"
