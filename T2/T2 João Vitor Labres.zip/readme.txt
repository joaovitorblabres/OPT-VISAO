# Rodar:
python t2-video.py

# Deixar o video com nome "WalkByShop1front.mpg" no mesmo diretório do arquivo Python, ele mostrará a saída do vídeo na tela e salvará frame a frame em uma pasta "imgs"
