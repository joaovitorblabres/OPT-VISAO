Execução:
python main.py

Resultados:
https://drive.google.com/open?id=1QEIdQNmomKCNk-_GmWz0GlMOERobxCMa

Melhor resultado foi o vídeo:
Q4_M15_B2_W35.avi

Com parametros para ShiTomasi Corner Detection:
qualityLevel = 0.4
minDistance = 15
blockSize = 2
E parametros para Lucas Kanade Optical Flow:
winSize = (35, 35)
maxLevel = 5
